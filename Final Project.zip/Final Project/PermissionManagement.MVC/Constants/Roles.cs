﻿namespace PermissionManagement.MVC.Constants
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Basic
    }
}